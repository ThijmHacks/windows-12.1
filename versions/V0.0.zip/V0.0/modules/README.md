# What is this?
So because I want to do this entire project from scratch, Ill make my own custom modules.

# Modules
## OS
This is basicly the default OS for python, except this one is made by me, and not by the real OS developer!