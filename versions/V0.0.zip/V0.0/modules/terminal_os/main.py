def clear():
    print("\033c", end="")  # Clears the terminal
